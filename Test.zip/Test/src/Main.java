public class Main {
    public static void main(String[] args) {
        double num = 2;
        double result = Test.sqrt(0,num,num);

        System.out.println(result);
    }
}