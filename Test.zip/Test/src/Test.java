class Test {
    static long i=0;
    static long times=10000;
    public static double sqrt(double low,double high,double num) {
        double mid=(high+low)/2;
        double square=mid*mid;

        if(i++==times) return mid;
        if (square<num) {
            low=mid;
            return sqrt(low,high,num);
        } else if (square>num) {
            high=mid;
            return sqrt(low,high,num);
        }else {
            return mid;
        }
    }
}